/*
 * Copyright 2020 McGraw-Hill Education. All rights reserved. No reproduction or distribution without the prior written consent of McGraw-Hill Education.
 */
#ifndef PATHS_H
#define PATHS_H

#define GLOBAL_RES_PATH "@ResPath@"
#define GLOBAL_TEST_PATH "@TestPath@"

#endif
