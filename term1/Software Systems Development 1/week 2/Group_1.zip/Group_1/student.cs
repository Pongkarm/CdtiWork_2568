﻿using System;

public class Student
{
    public int Id { get; set; }
    public string FullName { get; set; }
    public DateTime BirthDate { get; set; }
    public string Address { get; set; }
    public string Address1 { get; set; }
    public string Province { get; set; }
    public string Sex { get; set; }
    public string Nationality { get; set; }

    // Optional: Getter methods (ถ้ายังอยากใช้)
    public int GetID() => Id;
    public string GetFullName() => FullName;
    public DateTime GetBirthDate() => BirthDate;
    public string GetAddress() => Address;
    public string GetAddress1() => Address1;
    public string GetProvince() => Province;
    public string Getsex() => Sex;
    public string Getnationality() => Nationality;
}
