﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;

namespace WindowsFormsApp1
{
    

    public partial class Form1 : Form
	{
        string JsonPath => Path.Combine(Application.StartupPath, "students.json");
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadFromJson(JsonPath);   // ดึงไฟล์เก่าขึ้นมา (ถ้ามี)
        }

        List<Student> lstStudents = new List<Student>();
        int iCurrStudentIndex = 0;

		public Form1()
		{
			InitializeComponent();
            //Student stu1 = new Student();
            //stu1.SetID(1);
            //stu1.SetFullName("นายสมชาย ใจดี");
            //stu1.SetBirthDate(new DateTime(2000, 1, 1));
            //stu1.SetAddress("123/45 หมู่ 6 ต.บ้านใหม่ อ.เมือง จ.กรุงเทพฯ 12345");
            //lstStudents.Add(stu1);
            //stu1.SetID(2);
            //stu1.SetFullName("นายสศรี");
            //stu1.SetBirthDate(new DateTime(2000, 1, 1));
            //stu1.SetAddress("123/45 xxxหมู่ 6 ต.บ้านใหม่ อ.เมือง จ.กรุงเทพฯ 12345");
            //stu1.Setsex("หญิง");
            //lstStudents.Add(stu1);
            //Student stu2 = new Student();
            //stu2.SetID(3);
            //stu2.SetFullName("นางสาวสวย");
            //stu2.SetBirthDate(new DateTime(2000, 1, 1));
            //stu2.SetAddress("123/45 หมู่ 6 ต.บ้านใหม่ อ.เมือง จ.กรุงเทพฯ 12345");
            //stu2.Setsex("ชาย");

            //lstStudents.Add(stu2);


        }

        private void btClose_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button1_Click(object sender, EventArgs e)
		{
			if ( iCurrStudentIndex+1 < lstStudents.Count )
				iCurrStudentIndex++;
            tbRecordNo.Text = iCurrStudentIndex.ToString();
            tbId.Text = lstStudents[iCurrStudentIndex].GetID().ToString();
            tbFullName.Text = lstStudents[iCurrStudentIndex].GetFullName();
            if (lstStudents[iCurrStudentIndex].GetBirthDate() >= dtpBirthDate.MinDate &&
    lstStudents[iCurrStudentIndex].GetBirthDate() <= dtpBirthDate.MaxDate)
            {
                dtpBirthDate.Value = lstStudents[iCurrStudentIndex].GetBirthDate();
            }
            else
            {
                dtpBirthDate.Value = dtpBirthDate.MinDate; // Or handle invalid dates appropriately
            }
            tbAddress.Text = lstStudents[iCurrStudentIndex].GetAddress();
            comboBox1.Text = lstStudents[iCurrStudentIndex].Getsex();
            textBox2.Text = lstStudents[iCurrStudentIndex].GetAddress1();
        }
		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		int test()
		{
			return 0;
		}
		private void form2ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Form2 frm2 = new Form2();
			frm2.ShowDialog();
		}

		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void btPrev_Click(object sender, EventArgs e)
		{
			if ( iCurrStudentIndex> 0 )
				iCurrStudentIndex--;
			tbRecordNo.Text = iCurrStudentIndex.ToString();	
			tbId.Text = lstStudents[iCurrStudentIndex].GetID().ToString();
			tbFullName.Text = lstStudents[iCurrStudentIndex].GetFullName();
            DateTime birthDate = lstStudents[iCurrStudentIndex].GetBirthDate();
            if (birthDate >= dtpBirthDate.MinDate && birthDate <= dtpBirthDate.MaxDate)
            {
                dtpBirthDate.Value = birthDate;
            }
            else
            {
                dtpBirthDate.Value = dtpBirthDate.MinDate; // Or handle the invalid date appropriately
            }
            tbAddress.Text = lstStudents[iCurrStudentIndex].GetAddress();
            comboBox1.Text = lstStudents[iCurrStudentIndex].Getsex();
            textBox2.Text = lstStudents[iCurrStudentIndex].GetAddress1();

        }

        private void button2_Click(object sender, EventArgs e)
		{
			clearStudent();
		}
		void clearStudent()
		{
			tbRecordNo.Text = "";
			tbId.Text = "";
			tbFullName.Text = "";
			dtpBirthDate.Value = DateTime.Now;
			tbAddress.Text = "";
            textBox2.Text = "";
            comboBox2.Text = ""; // Assuming
            comboBox1.Text = ""; // Assuming these are Combo
        }
        private void btOK_Click(object sender, EventArgs e)
        {
            // ตรวจสอบว่ากรอกข้อมูลจำเป็นครบหรือยัง
            if (string.IsNullOrWhiteSpace(tbId.Text) ||
                string.IsNullOrWhiteSpace(tbFullName.Text) ||
                string.IsNullOrWhiteSpace(tbAddress.Text) ||
                string.IsNullOrWhiteSpace(comboBox1.Text)) // ตรวจเพศ
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบถ้วนก่อนบันทึก", "แจ้งเตือน", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // ยกเลิกการเซฟ
            }

            // แปลง ID อย่างปลอดภัย
            if (!long.TryParse(tbId.Text, out long id))
            {
                MessageBox.Show("กรุณากรอกหมายเลข ID ให้ถูกต้อง (ตัวเลขเท่านั้น)", "ข้อผิดพลาด", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // สร้างออบเจ็กต์
            Student stu = new Student
            {
                Id = (int)Convert.ToInt64(tbId.Text),
                FullName = tbFullName.Text,
                BirthDate = dtpBirthDate.Value,
                Address = tbAddress.Text,
                Address1 = textBox2.Text,
                Province = tbProvince.Text,
                Sex = comboBox1.Text,
                Nationality = comboBox2.Text
            };

            // เพิ่มลงรายการ
            lstStudents.Add(stu);
            SaveToJson(JsonPath);

            MessageBox.Show("บันทึกข้อมูลเรียบร้อยแล้ว!");
            clearStudent();
        }


        //location file json bin\Debug
        void SaveToJson(string filePath) =>
                File.WriteAllText(filePath,
                    JsonConvert.SerializeObject(lstStudents, Formatting.Indented),
                    Encoding.UTF8);

        void LoadFromJson(string filePath)
        {
            if (!File.Exists(filePath)) return;

            lstStudents = JsonConvert.DeserializeObject<List<Student>>(File.ReadAllText(filePath))
                          ?? new List<Student>();

            iCurrStudentIndex = 0;
            if (lstStudents.Count > 0) DisplayStudent(lstStudents[0]);
        }

        void DisplayStudent(Student stu)
        {
            tbId.Text = stu.GetID().ToString();
            tbFullName.Text = stu.GetFullName();
            if (stu.GetBirthDate() >= dtpBirthDate.MinDate && stu.GetBirthDate() <= dtpBirthDate.MaxDate)
            {
                dtpBirthDate.Value = stu.GetBirthDate();
            }
            else
            {
                dtpBirthDate.Value = dtpBirthDate.MinDate; // Or handle invalid dates appropriately
            }
            tbAddress.Text = stu.GetAddress();
            textBox2.Text = stu.GetAddress1();
            comboBox1.Text = stu.Getsex();
            comboBox2.Text = stu.Getnationality();
        }
        private void tbRecordNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbProvince_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //private void Form1_Load(object sender, EventArgs e)
        //{

        //}

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btd_refresh_Click(object sender, EventArgs e)
        {
            LoadFromJson("students.json");
            MessageBox.Show("โหลดข้อมูลเรียบร้อยแล้ว!");
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void tbId_TextChanged(object sender, EventArgs e)
        {
            // ถ้ายาวเกิน 9 หลัก ให้ตัดส่วนเกินทิ้ง
            if (tbId.Text.Length > 9)
            {
                tbId.Text = tbId.Text.Substring(0, 9);
                tbId.SelectionStart = tbId.Text.Length; // ให้เคอร์เซอร์อยู่ท้ายสุด
            }
        }
    }
}
