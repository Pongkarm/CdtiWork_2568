﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Group_2
{
    public partial class Form1 : Form
    {
        private Dictionary<string, ClientAccessInfo> ipStats = new();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public class ClientAccessInfo
        {
            public string Host { get; set; }
            public string Country { get; set; } = "Private IP";
            public string RiskLevel { get; set; } = "None";
            public int Hits { get; set; } = 0;
            public int PageViews { get; set; } = 0;
            public long ClientToServerBytes { get; set; } = 0;
            public long ServerToClientBytes { get; set; } = 0;
            public long TotalBandwidth => ClientToServerBytes + ServerToClientBytes;
        }

        private void PictureBox1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Log Files (*.log)|*.log";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ParseLogFile(ofd.FileName);
                DisplayToGrid();
            }
        }
        

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Log Files (*.log)|*.log";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ParseLogFile(ofd.FileName);
                DisplayToGrid(); // ✅ แสดงผลในตาราง
            }
        }

        private string[] logFields;

        private void ParseLogFile(string path)
        {
            ipStats.Clear();

            foreach (var line in File.ReadLines(path))
            {
                if (line.StartsWith("#Fields:"))
                {
                    logFields = line.Substring(8).Trim().Split(' ');
                    continue;
                }

                if (line.StartsWith("#") || string.IsNullOrWhiteSpace(line)) continue;

                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (logFields == null || parts.Length != logFields.Length) continue;


                try
                {
                    var dict = new Dictionary<string, string>();
                    int limit = Math.Min(logFields.Length, parts.Length);
                    for (int i = 0; i < limit; i++)
                        dict[logFields[i]] = parts[i];


                    string ip = dict.ContainsKey("c-ip") ? dict["c-ip"] : "-";
                    long csBytes = dict.TryGetValue("cs-bytes", out string csVal) && long.TryParse(csVal, out long cs) ? cs : 0;
                    long scBytes = dict.TryGetValue("sc-bytes", out string scVal) && long.TryParse(scVal, out long sc) ? sc : 0;

                    if (!ipStats.ContainsKey(ip))
                    {
                        ipStats[ip] = new ClientAccessInfo
                        {
                            Host = ip,
                            RiskLevel = AssessRisk(ip)
                        };
                    }

                    ipStats[ip].Hits++;
                    ipStats[ip].ClientToServerBytes += csBytes;
                    ipStats[ip].ServerToClientBytes += scBytes;

                    string uri = dict.ContainsKey("cs-uri-stem") ? dict["cs-uri-stem"] : "";
                    if (uri.EndsWith(".html") || uri.EndsWith(".htm") || uri.EndsWith(".php") || uri.EndsWith(".aspx"))
                    {
                        ipStats[ip].PageViews++;
                    }


                    ipStats[ip].Hits++;
                    ipStats[ip].ClientToServerBytes += csBytes;
                    ipStats[ip].ServerToClientBytes += scBytes;
                    ipStats[ip].PageViews += 1;

                }

                catch { continue; }
            }
        }

        private void DisplayToGrid()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Host");
            table.Columns.Add("Country");
            table.Columns.Add("Risk Level");
            table.Columns.Add("Hits");
            table.Columns.Add("Page View");
            table.Columns.Add("Client-To-Server BytesSent");
            table.Columns.Add("Server-To-Client BytesSent");
            table.Columns.Add("Bandwidth Bytes");

            foreach (var ip in ipStats.Values)
            {
                table.Rows.Add(
                    ip.Host,
                    ip.Country,
                    ip.RiskLevel,
                    FormatHits(ip.Hits),
                    FormatViews(ip.PageViews),
                    FormatBytes(ip.ClientToServerBytes),
                    FormatBytes(ip.ServerToClientBytes),
                    FormatBytes(ip.TotalBandwidth)
                );
            }

            dataGridView1.DataSource = table;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Log Files (*.log)|*.log";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ParseLogFile(ofd.FileName);
                DisplayToGrid(); // ✅ แสดงผลในตาราง
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Host");
            table.Columns.Add("Country");
            table.Columns.Add("Risk Level");
            table.Columns.Add("Hits");
            table.Columns.Add("Page View");
            table.Columns.Add("Client-To-Server BytesSent");
            table.Columns.Add("Server-To-Client BytesSent");
            table.Columns.Add("Bandwidth Bytes");

            foreach (var ip in ipStats.Values)
            {
                table.Rows.Add(
                    ip.Host,
                    ip.Country,
                    ip.RiskLevel,
                    $"{ip.Hits} Hit",
                    "",
                    $"{ip.ClientToServerBytes} Byte",
                    $"{ip.ServerToClientBytes} Byte",
                    $"{ip.TotalBandwidth} Byte"
                );
            }

            dataGridView1.DataSource = table;
        }
        private string FormatBytes(long bytes)
        {
            if (bytes >= 1024 * 1024 * 1024)
                return $"{bytes / (1024.0 * 1024 * 1024):0.##} GByte";
            if (bytes >= 1024 * 1024)
                return $"{bytes / (1024.0 * 1024):0.##} MByte";
            if (bytes >= 1024)
                return $"{bytes / 1024.0:0.##} kByte";
            return $"{bytes} Byte";
        }

        private string FormatHits(int hits)
        {
            return hits >= 1000 ? $"{hits / 1000.0:0.##} kHit" : $"{hits} Hit";
        }

        private string FormatViews(int views)
        {
            return views >= 1000 ? $"{views / 1000.0:0.##} kView" : $"{views} View";
        }

        private string AssessRisk(string ip)
        {
            if (ip.StartsWith("192.168.1.")) return "Low";
            if (ip.StartsWith("192.168.2.")) return "Medium";
            if (ip.StartsWith("172.31.")) return "High"; // ตั้งสมมติว่าคือ subnet อันตราย
            if (ip.StartsWith("192.168.") || ip.StartsWith("172.") || ip.StartsWith("10.")) return "None";
            if (ip.StartsWith("167.") || ip.Contains(".78.")) return "Medium";
            if (ip.StartsWith("185.") || ip.StartsWith("200.") || ip.StartsWith("179.")) return "High";

            return "Low";
        }


    }
}