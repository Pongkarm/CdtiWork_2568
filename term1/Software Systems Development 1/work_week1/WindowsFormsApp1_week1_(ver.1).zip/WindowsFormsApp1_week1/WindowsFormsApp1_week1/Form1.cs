﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1_week1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button_register_Click(object sender, EventArgs e)
        {
            string name = user_input.Text;
            string studentID = student_id_input.Text;
            string regDate = date_time_register_input.Value.ToShortDateString(); // หรือ Format ตามใจชอบ
            string activity = comboBox1.Text;
            string gender = gender_input.Text;
            string age = age_input.Text;
            bool isInterested = checkBox1.Checked;

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(studentID) || string.IsNullOrWhiteSpace(activity) || string.IsNullOrWhiteSpace(age))
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ครบถ้วน", "ข้อผิดพลาด");
                return;
            }
            if (string.IsNullOrWhiteSpace(gender) ||
                (gender != "ชาย" && gender != "หญิง" && gender != "ไม่ระบุ"))
            {
                MessageBox.Show("กรุณาเลือกเพศให้ถูกต้อง (ชาย, หญิง หรือ อื่นๆ)", "ข้อผิดพลาด");
                return;
            }

            if (isInterested == false)
            {
                MessageBox.Show("กรุณายืนยันความสมัครใจในกิจกรรม", "ข้อผิดพลาด");
                return;
            }
  

            // แจ้งเตือนผู้ใช้
            MessageBox.Show("บันทึกข้อมูลเรียบร้อยแล้ว!", "Success");
            Form2 form2 = new Form2(name, studentID, regDate, activity, gender, age, isInterested);
            form2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void user_input_TextChanged(object sender, EventArgs e)
        {

        }

        private void student_id_label_Click(object sender, EventArgs e)
        {

        }

        private void student_id_input_TextChanged(object sender, EventArgs e)
        {

        }

        private void reset_info_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void reset_info_MouseClick(object sender, MouseEventArgs e)
        {
            if (MessageBox.Show("ต้องการล้างข้อมูลทั้งหมดหรือไม่?", "ยืนยัน", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                user_input.Text = "";
                student_id_input.Text = "";
                comboBox1.SelectedIndex = -1;
                gender_input.Text = "";
                age_input.Text = "";
                checkBox1.Checked = false;
            }

        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }
    }
}
