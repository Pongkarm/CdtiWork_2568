﻿namespace WindowsFormsApp1_week1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name_output = new System.Windows.Forms.Label();
            this.button_back = new System.Windows.Forms.Button();
            this.report = new System.Windows.Forms.Label();
            this.student_id_output = new System.Windows.Forms.Label();
            this.date_output = new System.Windows.Forms.Label();
            this.activity_output = new System.Windows.Forms.Label();
            this.gender_output = new System.Windows.Forms.Label();
            this.age_output = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // name_output
            // 
            this.name_output.AutoSize = true;
            this.name_output.Location = new System.Drawing.Point(24, 47);
            this.name_output.Name = "name_output";
            this.name_output.Size = new System.Drawing.Size(20, 13);
            this.name_output.TabIndex = 0;
            this.name_output.Text = "ชื่อ";
            this.name_output.Click += new System.EventHandler(this.name_output_Click);
            // 
            // button_back
            // 
            this.button_back.Location = new System.Drawing.Point(117, 215);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(70, 23);
            this.button_back.TabIndex = 1;
            this.button_back.Text = "กลับ";
            this.button_back.UseVisualStyleBackColor = true;
            this.button_back.Click += new System.EventHandler(this.button_back_Click);
            // 
            // report
            // 
            this.report.AutoSize = true;
            this.report.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.report.Location = new System.Drawing.Point(94, 9);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(113, 20);
            this.report.TabIndex = 2;
            this.report.Text = "ผลการลงทะเบียน";
            // 
            // student_id_output
            // 
            this.student_id_output.AutoSize = true;
            this.student_id_output.Location = new System.Drawing.Point(24, 73);
            this.student_id_output.Name = "student_id_output";
            this.student_id_output.Size = new System.Drawing.Size(26, 13);
            this.student_id_output.TabIndex = 3;
            this.student_id_output.Text = "รหัส";
            // 
            // date_output
            // 
            this.date_output.AutoSize = true;
            this.date_output.Location = new System.Drawing.Point(24, 102);
            this.date_output.Name = "date_output";
            this.date_output.Size = new System.Drawing.Size(78, 13);
            this.date_output.TabIndex = 4;
            this.date_output.Text = "วันที่ลงทะเบียน";
            // 
            // activity_output
            // 
            this.activity_output.AutoSize = true;
            this.activity_output.Location = new System.Drawing.Point(24, 133);
            this.activity_output.Name = "activity_output";
            this.activity_output.Size = new System.Drawing.Size(46, 13);
            this.activity_output.TabIndex = 5;
            this.activity_output.Text = "กิจกรรม";
            // 
            // gender_output
            // 
            this.gender_output.AutoSize = true;
            this.gender_output.Location = new System.Drawing.Point(24, 163);
            this.gender_output.Name = "gender_output";
            this.gender_output.Size = new System.Drawing.Size(28, 13);
            this.gender_output.TabIndex = 6;
            this.gender_output.Text = "เพศ";
            this.gender_output.Click += new System.EventHandler(this.gender_output_Click);
            // 
            // age_output
            // 
            this.age_output.AutoSize = true;
            this.age_output.Location = new System.Drawing.Point(24, 191);
            this.age_output.Name = "age_output";
            this.age_output.Size = new System.Drawing.Size(25, 13);
            this.age_output.TabIndex = 7;
            this.age_output.Text = "อายุ";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 250);
            this.Controls.Add(this.age_output);
            this.Controls.Add(this.gender_output);
            this.Controls.Add(this.activity_output);
            this.Controls.Add(this.date_output);
            this.Controls.Add(this.student_id_output);
            this.Controls.Add(this.report);
            this.Controls.Add(this.button_back);
            this.Controls.Add(this.name_output);
            this.Name = "Form2";
            this.Text = "ผลการลงทะเบียน";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name_output;
        private System.Windows.Forms.Button button_back;
        private System.Windows.Forms.Label report;
        private System.Windows.Forms.Label student_id_output;
        private System.Windows.Forms.Label date_output;
        private System.Windows.Forms.Label activity_output;
        private System.Windows.Forms.Label gender_output;
        private System.Windows.Forms.Label age_output;
    }
}