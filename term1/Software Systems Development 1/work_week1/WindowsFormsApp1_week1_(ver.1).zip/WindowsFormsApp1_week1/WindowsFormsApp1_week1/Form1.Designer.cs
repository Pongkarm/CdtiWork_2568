﻿namespace WindowsFormsApp1_week1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name_user = new System.Windows.Forms.Label();
            this.user_input = new System.Windows.Forms.TextBox();
            this.button_register = new System.Windows.Forms.Button();
            this.date_time_register_input = new System.Windows.Forms.DateTimePicker();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.student_id_label = new System.Windows.Forms.Label();
            this.student_id_input = new System.Windows.Forms.TextBox();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.date_time_register_label = new System.Windows.Forms.Label();
            this.reset_info = new System.Windows.Forms.LinkLabel();
            this.Haeder = new System.Windows.Forms.Label();
            this.gender_input = new System.Windows.Forms.ComboBox();
            this.gender_label = new System.Windows.Forms.Label();
            this.age_label = new System.Windows.Forms.Label();
            this.age_input = new System.Windows.Forms.TextBox();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // name_user
            // 
            this.name_user.AutoSize = true;
            this.name_user.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_user.Location = new System.Drawing.Point(51, 97);
            this.name_user.Name = "name_user";
            this.name_user.Size = new System.Drawing.Size(24, 18);
            this.name_user.TabIndex = 0;
            this.name_user.Text = "ชื่อ";
            this.name_user.Click += new System.EventHandler(this.label1_Click);
            // 
            // user_input
            // 
            this.user_input.Location = new System.Drawing.Point(134, 94);
            this.user_input.Name = "user_input";
            this.user_input.Size = new System.Drawing.Size(177, 20);
            this.user_input.TabIndex = 1;
            this.user_input.TextChanged += new System.EventHandler(this.user_input_TextChanged);
            // 
            // button_register
            // 
            this.button_register.AutoSize = true;
            this.button_register.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button_register.Location = new System.Drawing.Point(145, 409);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(83, 32);
            this.button_register.TabIndex = 2;
            this.button_register.Text = "ลงทะเบียน";
            this.button_register.UseVisualStyleBackColor = false;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // date_time_register_input
            // 
            this.date_time_register_input.Location = new System.Drawing.Point(134, 188);
            this.date_time_register_input.Name = "date_time_register_input";
            this.date_time_register_input.Size = new System.Drawing.Size(208, 20);
            this.date_time_register_input.TabIndex = 3;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(134, 386);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(119, 17);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "ยีนยันความสมัครใจ";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "กิจกรรมเลี้ยงสัตว์",
            "กิจกรรมเที่ยวป่า",
            "กิจกรรมว่ายน้ำ",
            "กิจกรรมเลี้ยงปลา"});
            this.comboBox1.Location = new System.Drawing.Point(134, 231);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(115, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(377, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // student_id_label
            // 
            this.student_id_label.AutoSize = true;
            this.student_id_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student_id_label.Location = new System.Drawing.Point(36, 137);
            this.student_id_label.Name = "student_id_label";
            this.student_id_label.Size = new System.Drawing.Size(80, 18);
            this.student_id_label.TabIndex = 7;
            this.student_id_label.Text = "รหัสนักศึกษา";
            this.student_id_label.Click += new System.EventHandler(this.student_id_label_Click);
            // 
            // student_id_input
            // 
            this.student_id_input.Location = new System.Drawing.Point(134, 137);
            this.student_id_input.Name = "student_id_input";
            this.student_id_input.Size = new System.Drawing.Size(177, 20);
            this.student_id_input.TabIndex = 8;
            this.student_id_input.TextChanged += new System.EventHandler(this.student_id_input_TextChanged);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "เลือกกิจกรรม";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // date_time_register_label
            // 
            this.date_time_register_label.AutoSize = true;
            this.date_time_register_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_time_register_label.Location = new System.Drawing.Point(35, 188);
            this.date_time_register_label.Name = "date_time_register_label";
            this.date_time_register_label.Size = new System.Drawing.Size(92, 18);
            this.date_time_register_label.TabIndex = 10;
            this.date_time_register_label.Text = "วันที่ลงทะเบียน";
            this.date_time_register_label.Click += new System.EventHandler(this.label4_Click);
            // 
            // reset_info
            // 
            this.reset_info.AutoSize = true;
            this.reset_info.LinkColor = System.Drawing.Color.White;
            this.reset_info.Location = new System.Drawing.Point(317, 438);
            this.reset_info.Name = "reset_info";
            this.reset_info.Size = new System.Drawing.Size(48, 13);
            this.reset_info.TabIndex = 11;
            this.reset_info.TabStop = true;
            this.reset_info.Text = "ล้างข้อมูล";
            this.reset_info.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.reset_info_LinkClicked);
            this.reset_info.MouseClick += new System.Windows.Forms.MouseEventHandler(this.reset_info_MouseClick);
            // 
            // Haeder
            // 
            this.Haeder.AutoSize = true;
            this.Haeder.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Haeder.Location = new System.Drawing.Point(76, 37);
            this.Haeder.Name = "Haeder";
            this.Haeder.Size = new System.Drawing.Size(257, 31);
            this.Haeder.TabIndex = 12;
            this.Haeder.Text = "แบบฟอร์มเลือกกิจกรรม";
            this.Haeder.Click += new System.EventHandler(this.label5_Click);
            // 
            // gender_input
            // 
            this.gender_input.FormattingEnabled = true;
            this.gender_input.Items.AddRange(new object[] {
            "ชาย",
            "หญิง",
            "ไม่ระบุ"});
            this.gender_input.Location = new System.Drawing.Point(134, 283);
            this.gender_input.Name = "gender_input";
            this.gender_input.Size = new System.Drawing.Size(69, 21);
            this.gender_input.TabIndex = 13;
            // 
            // gender_label
            // 
            this.gender_label.AutoSize = true;
            this.gender_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender_label.Location = new System.Drawing.Point(51, 283);
            this.gender_label.Name = "gender_label";
            this.gender_label.Size = new System.Drawing.Size(34, 20);
            this.gender_label.TabIndex = 14;
            this.gender_label.Text = "เพศ";
            // 
            // age_label
            // 
            this.age_label.AutoSize = true;
            this.age_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age_label.Location = new System.Drawing.Point(51, 334);
            this.age_label.Name = "age_label";
            this.age_label.Size = new System.Drawing.Size(32, 20);
            this.age_label.TabIndex = 15;
            this.age_label.Text = "อายุ";
            this.age_label.Click += new System.EventHandler(this.label6_Click);
            // 
            // age_input
            // 
            this.age_input.Location = new System.Drawing.Point(134, 334);
            this.age_input.Name = "age_input";
            this.age_input.Size = new System.Drawing.Size(60, 20);
            this.age_input.TabIndex = 16;
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(377, 460);
            this.Controls.Add(this.age_input);
            this.Controls.Add(this.age_label);
            this.Controls.Add(this.gender_label);
            this.Controls.Add(this.gender_input);
            this.Controls.Add(this.Haeder);
            this.Controls.Add(this.reset_info);
            this.Controls.Add(this.date_time_register_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.student_id_input);
            this.Controls.Add(this.student_id_label);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.date_time_register_input);
            this.Controls.Add(this.button_register);
            this.Controls.Add(this.user_input);
            this.Controls.Add(this.name_user);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "โปรแกรมลงทะเบียนกิจกรรม";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name_user;
        private System.Windows.Forms.TextBox user_input;
        private System.Windows.Forms.Button button_register;
        private System.Windows.Forms.DateTimePicker date_time_register_input;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label student_id_label;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.TextBox student_id_input;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label date_time_register_label;
        private System.Windows.Forms.LinkLabel reset_info;
        private System.Windows.Forms.Label Haeder;
        private System.Windows.Forms.ComboBox gender_input;
        private System.Windows.Forms.Label gender_label;
        private System.Windows.Forms.Label age_label;
        private System.Windows.Forms.TextBox age_input;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
    }
}

