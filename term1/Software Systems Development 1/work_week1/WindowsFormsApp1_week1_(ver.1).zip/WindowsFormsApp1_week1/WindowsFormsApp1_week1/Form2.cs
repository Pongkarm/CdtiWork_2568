﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_week1
{
    public partial class Form2 : Form
    {

        public Form2(string name, string studentID, string regDate, string activity, string gender, string age, bool isInterested)
        {
            InitializeComponent();

            name_output.Text = $"ชื่อ: {name}";
            student_id_output.Text = $"รหัสนักศึกษา: {studentID}";
            date_output.Text = $"วันที่ลงทะเบียน: {regDate}";
            activity_output.Text = $"กิจกรรม: {activity}";
            gender_output.Text = $"เพศ: {gender}";
            age_output.Text = $"อายุ: {age}";

        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button_back_Click(object sender, EventArgs e)
        {
            // ปิด Form2 และกลับไปยัง Form1
            this.Close();
        }

        private void name_output_Click(object sender, EventArgs e)
        {

        }

        private void gender_output_Click(object sender, EventArgs e)
        {

        }
    }
}
